document.addEventListener("DOMContentLoaded",()=>{
 const f=document.getElementById("signupForm"),msg=document.getElementById("signupMessage");
 const bindPasswordToggle=(buttonId,inputId)=>{
  const button=document.getElementById(buttonId),input=document.getElementById(inputId);
  button?.addEventListener("click",()=>{
   const reveal=input.type==="password";
   input.type=reveal?"text":"password";
   button.setAttribute("aria-label",reveal?"Hide password":"Show password");
   button.setAttribute("aria-pressed",String(reveal));
  });
 };
 bindPasswordToggle("toggleNewPassword","newPassword");
 bindPasswordToggle("toggleConfirmPassword","confirmPassword");
 f?.addEventListener("submit",async e=>{e.preventDefault();
  const fullName=document.getElementById("fullName").value.trim(),username=document.getElementById("newUsername").value.trim(),email=document.getElementById("email").value.trim(),phone=document.getElementById("phone").value.trim(),password=document.getElementById("newPassword").value,confirmPassword=document.getElementById("confirmPassword").value;
  if(!fullName||!username||!email||!phone||!password||!confirmPassword)return msg.textContent="Please fill in all required fields.";
  if(password!==confirmPassword)return msg.textContent="Passwords do not match.";
  if(!/^\d{10}$/.test(phone))return msg.textContent="Enter a valid 10-digit phone number.";
  if(password.length<8||!/[A-Z]/.test(password)||!/[a-z]/.test(password)||!/\d/.test(password)||!/[^\w]/.test(password))return msg.textContent="Password must contain 8+ chars, upper, lower, number and special character.";
  try{const d=await fintrackApi("/auth/register",{method:"POST",body:JSON.stringify({fullName,username,email,phone,password,confirmPassword})});msg.textContent=d.message;f.reset();setTimeout(()=>location.href="admin-login.html",1000);}catch(err){msg.textContent=err.message.includes("Admin registration is closed")?"An admin account already exists. Sign in as an administrator, then use the ⋮ menu → Create Admin.":err.message;}
 });
});
