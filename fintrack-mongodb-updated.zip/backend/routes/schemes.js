const express=require("express");
const Scheme=require("../models/Scheme");
const MemberSchemeTicket=require("../models/MemberSchemeTicket");
const Member=require("../models/Member");
const Winner=require("../models/Winner");
const {requireAuth,requireRole}=require("../middleware/auth");
const router=express.Router();

function out(s){const x=s.toObject();x.id=x._id.toString();x.type=x.chitType;delete x._id;delete x.__v; if(x.goldMonthlyInstallments instanceof Map)x.goldMonthlyInstallments=Object.fromEntries(x.goldMonthlyInstallments); return x;}
function cleanGoldInstallments(value,duration){
  if(!Number.isInteger(Number(duration))||Number(duration)<1||Number(duration)>30)return null;
  if(!value||typeof value!=="object")return null;
  const result={};
  for(const [key,raw] of Object.entries(value)){
    const month=Number(key),amount=Number(raw);
    if(!Number.isInteger(month)||month<1||month>Number(duration)||!Number.isFinite(amount)||amount<=0)return null;
    result[String(month)]=amount;
  }
  return Number(result["1"])>0?result:null;
}

router.get("/",requireAuth,async(req,res)=>{
  const schemes=await Scheme.find().sort({createdAt:-1}); res.json({success:true,schemes:schemes.map(out)});
});
router.get("/:id",requireAuth,async(req,res)=>{
  const s=await Scheme.findById(req.params.id); if(!s)return res.status(404).json({success:false,message:"Scheme not found"});
  res.json({success:true,scheme:out(s)});
});
router.post("/",requireAuth,requireRole("admin"),async(req,res)=>{
  const b=req.body; const duration=Number(b.duration); const chitType=String(b.chitType||b.type||"cash").toLowerCase();
  if(chitType==="gold"){
    const installments=cleanGoldInstallments(b.goldMonthlyInstallments,duration);
    if(!installments)return res.status(400).json({success:false,message:"Enter a valid Month 1 installment amount."});
    b.goldMonthlyInstallments=installments;
    b.baseAmount=installments["1"];
  }
  const data={name:b.name?.trim(),chitType,totalAmount:Number(b.totalAmount||0),baseAmount:Number(b.baseAmount||0),goldGrams:Number(b.goldGrams||0),takenPayment:Number(b.takenPayment||0),goldMonthlyInstallments:chitType==="gold"?b.goldMonthlyInstallments:undefined,duration,capacity:Number(b.capacity),startDate:b.startDate,status:b.status||"upcoming"};
  const s=await Scheme.create(data); res.status(201).json({success:true,scheme:out(s)});
});
router.patch("/:id",requireAuth,requireRole("admin"),async(req,res)=>{
  const existing=await Scheme.findById(req.params.id); if(!existing)return res.status(404).json({success:false,message:"Scheme not found"});
  const allowed=["name","chitType","type","totalAmount","baseAmount","goldGrams","takenPayment","goldMonthlyInstallments","duration","capacity","startDate","status"];
  const b={}; for(const k of allowed) if(req.body[k]!==undefined)b[k]=k==="type"?"chitType":req.body[k];
  if(b.chitType)b.chitType=String(b.chitType).toLowerCase();
  const chitType=b.chitType||existing.chitType;
  const duration=Number(b.duration??existing.duration);
  const scheduleChanged=b.goldMonthlyInstallments!==undefined||b.duration!==undefined||b.chitType!==undefined;
  if(chitType==="gold"&&scheduleChanged){
    const current=existing.goldMonthlyInstallments instanceof Map?Object.fromEntries(existing.goldMonthlyInstallments):existing.goldMonthlyInstallments;
    const installments=cleanGoldInstallments(b.goldMonthlyInstallments??current,duration);
    if(!installments)return res.status(400).json({success:false,message:"Enter a valid Month 1 installment amount and positive values for any months already configured."});
    b.goldMonthlyInstallments=installments;
    b.baseAmount=installments["1"];
  }
  let s;
  if(chitType!=="gold"&&existing.chitType==="gold")s=await Scheme.findByIdAndUpdate(req.params.id,{$set:b,$unset:{goldMonthlyInstallments:1}},{new:true,runValidators:true});
  else s=await Scheme.findByIdAndUpdate(req.params.id,b,{new:true,runValidators:true});
  if(!s)return res.status(404).json({success:false,message:"Scheme not found"});
  res.json({success:true,scheme:out(s)});
});
router.delete("/:id",requireAuth,requireRole("admin"),async(req,res)=>{
  const used=await MemberSchemeTicket.exists({scheme:req.params.id})||await Winner.exists({scheme:req.params.id});
  if(used)return res.status(409).json({success:false,message:"Scheme has tickets or winners and cannot be deleted"});
  const s=await Scheme.findByIdAndDelete(req.params.id); if(!s)return res.status(404).json({success:false,message:"Scheme not found"});
  res.json({success:true});
});
router.get("/:id/tickets",requireAuth,async(req,res)=>{
  const filter={scheme:req.params.id};
  if(req.user.role==="user")filter.member=req.user.memberId;
  const rows=await MemberSchemeTicket.find(filter).populate("member","name email phone status joinedDate").sort({ticketNumber:1});
  res.json({success:true,tickets:rows});
});
module.exports=router;
